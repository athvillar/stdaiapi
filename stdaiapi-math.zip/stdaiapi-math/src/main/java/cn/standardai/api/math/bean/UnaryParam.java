package cn.standardai.api.math.bean;

public abstract class UnaryParam<T> extends QuestionParam<UnaryParam<T>> {

	public T p;
}

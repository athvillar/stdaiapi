package cn.standardai.api.math.bean;

public abstract class BinaryParam<T> extends QuestionParam<BinaryParam<T>> {

	public T p1;

	public T p2;
}
